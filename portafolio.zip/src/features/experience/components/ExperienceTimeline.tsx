'use client';

import { motion } from 'framer-motion';
import { experiences } from "../data/experience";
import { ExperienceItem } from "./ExperienceItem";

export function ExperienceTimeline() {
  return (
    <motion.div className="relative mt-20">

      <motion.div className="absolute left-4 top-0 h-full w-px bg-border" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.7, ease: 'easeOut' }} />

      <div className="space-y-12">
        {experiences.map((experience) => (
          <div key={experience.id} className="relative pl-14 sm:pl-16">
            <div className="absolute left-0 top-10 h-4 w-4 rounded-full border-4 border-background bg-primary" />

            <ExperienceItem
              experience={experience}
            />

          </div>

        ))}

      </div>

    </motion.div>
  );
}