type SectionTitleProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  align?: 'left' | 'center';
};

export function SectionTitle({
  eyebrow,
  title,
  description,
  align = 'left',
}: SectionTitleProps) {
  return (
    <div
      className={
        align === 'center'
          ? 'mx-auto max-w-2xl text-center mb-6'
          : 'max-w-2xl mb-6'
      }
    >
      {eyebrow && (
        <span className="text-sm font-semibold uppercase tracking-[0.18em] text-primary">
          {eyebrow}
        </span>
      )}

      <h2 className="mt-3 text-2xl font-semibold tracking-tight sm:text-3xl md:text-4xl">
        {title}
      </h2>

      {description && (
        <p className="mt-3 max-w-2xl leading-7 text-muted-foreground">
          {description}
        </p>
      )}
    </div>
  );
}