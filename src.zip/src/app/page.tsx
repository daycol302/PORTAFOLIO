import { About } from "@/features/about";
import { Experience } from "@/features/experience";
import Hero from "@/features/hero/components/Hero";

export default function HomePage() {
  return (
    <main>
      <Hero />
      <About />
      <Experience />
    </main>
  );
}
