export const siteConfig = {
  name: 'Portafolio',
  description: '',
  url: process.env.NEXT_PUBLIC_SITE_URL ?? 'http://localhost:3000',
  locale: 'es',
  keywords: [] as string[],
  author: {
    name: '',
    twitter: '',
  },
  nav: [
    { label: 'Inicio', href: '/' },
    { label: 'Proyectos', href: '#projects' },
    { label: 'Sobre mí', href: '#about' },
    { label: 'Contacto', href: '#contact' },
  ],
  links: {
    github: '',
    linkedin: '',
    email: '',
  },
} as const;

export type SiteConfig = typeof siteConfig;

export type NavItem = (typeof siteConfig.nav)[number];
